# RK_playerMobile

Diseño del player en su versión móvil

PROPIEDAD DE RED KARAOKE